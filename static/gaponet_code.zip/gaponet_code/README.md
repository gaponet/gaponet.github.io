# GapONet: Bridging the Nonlinear Sim-to-Real Gap under Payload Variation via Operator Learning

GapONet learns a payload-conditioned residual operator for humanoid sim-to-real transfer. It maps an online dynamics context, inferred from recent motion, and a commanded action to a residual action that compensates for the nonlinear gap induced by payload variation.

## Overview

Payload does not shift humanoid dynamics by a constant offset: its effect couples with posture, velocity, acceleration, contact, and actuator behavior. GapONet treats this state-dependent residual as an operator-learning problem rather than a per-payload parameter-identification problem.

The accompanying TWINS dataset provides 30,808 paired sim-real sequences, about 205 hours and 36.9M frames, under a controlled 0-3 kg per-wrist payload sweep across three platforms and three simulators. GapONet uses a DeepONet-style branch-trunk factorization: the branch encodes the measured dynamics context, while the trunk encodes the commanded action. Keeping these factors separate lets the learned correction recombine across unseen payload-motion pairs and held-out robot units.

Headline results reported in the paper:

- Large-gap ratio (LGR) stays below 1% across the full 0-3 kg sweep.
- At the 3 kg per-wrist limit, GapONet reaches 0.84% LGR versus 6.25% for the strongest non-operator baseline.
- The same recipe is evaluated on Unitree H1-2, Fourier GR, and RealMan wheeled dual-arm platforms.
- Hardware deployment uses the sign-flipped operator as an online compensator with zero per-robot calibration; hardware runs are reported over 0-1 kg, while the full 0-3 kg range is established in paired sim-real evaluation.

## Prerequisites

- **Isaac Sim 4.5.0+** (installed separately)
- **Python 3.10+**
- **CUDA-capable GPU** with appropriate drivers
- **Isaac Lab** (see [Isaac Lab documentation](https://isaac-sim.github.io/IsaacLab/) for installation)

## Assets

Before running experiments, download or stage the required assets:

1. **Robot Assets**: Download the `sim2real_assets` package from the project release channel and place the corresponding files in `gaponet/source/sim2real_assets/sim2real_assets/`.

2. **TWINS Motion Data**: Place paired motion `.npz` files in `gaponet/source/sim2real/sim2real/tasks/humanoid_operator/motions/motion_amass/edited_27dof/`.

3. **Checkpoint**: Place trained checkpoints in `gaponet/model/`.

## Installation

Install Isaac Sim and Isaac Lab first, then install GapONet from this directory:

```bash
# Clone the repository - HTTPS (recommended for agents / CI / unattended setups)
git clone https://github.com/gaponet/gaponet_code.git
cd gaponet_code

# Install IsaacSim
pip install "isaacsim[all,extscache]==4.5.0" --extra-index-url https://pypi.nvidia.com

# Install Isaac Lab separately following the Isaac Lab documentation.
# Then install GapONet from this directory.
pip install -e .
```

## Usage

### Training

Train the operator policy on the humanoid operator task:

```bash
python scripts/rsl_rl/train.py --task Isaac-Humanoid-Operator-Delta-Action \
  --num_envs=4080 --max_iterations 100000 --experiment_name Sim2Real \
  --letter amass --run_name gaponet_operator --device cuda env.mode=train --headless
```

### Evaluation/Playback

1. Evaluate a trained model:

```bash
python scripts/rsl_rl/play.py --task Isaac-Humanoid-Operator-Delta-Action  \
   --model ./model/model_17950.pt --num_envs 20 --headless
```

2. **Export checkpoint to JIT format** (for lightweight inference without Isaac Sim):

```bash
python scripts/rsl_rl/inference_jit.py \
    --export \
    --checkpoint ./model/model_17950.pt \
    --task Isaac-Humanoid-Operator-Delta-Action \
    --output ./model/policy.pt \
    --device cuda:0 \
    --num_envs 20
```

   This script exports a trained checkpoint to JIT/TorchScript format. The exported model can be used for inference without requiring Isaac Sim. Note: This step requires Isaac Sim to be initialized for the export process.

3. **Run lightweight inference and evaluation** (no Isaac Sim required):

```bash
python scripts/rsl_rl/deploy.py \
    --model ./model/policy.pt \
    --test_data ./source/sim2real/sim2real/tasks/humanoid_operator/motions/motion_amass/edited_27dof/test.npz \
```

   This script performs inference on paired test data and computes the paper-aligned metrics:
   - **Large-Gap Ratio (LGR, %)**: percentage of frame-joint samples with absolute position gap `e_{t,j} >= 0.5 rad`.
   - **Gap IQR (rad)**: `Q75(e) - Q25(e)`, the robust spread of the absolute joint-position gap.
   
   Results are grouped by payload mass and displayed in tables. This script does not require Isaac Sim and can be run on any machine with PyTorch.


## Architecture

### Branch-Trunk Operator

GapONet uses a DeepONet-style factorization over the residual action:
- **Dynamics context**: a 400-D representation of the local actuation regime, predicted online from recent motion history.
- **Branch network**: encodes the dynamics context, including payload-, posture-, and actuator-dependent effects.
- **Trunk network**: encodes the commanded action.
- **Basiswise product**: fuses branch and trunk features to output the residual action.

This separation is the key design choice: the dynamics representation is reusable across commands, and the command representation is reusable across payload regimes.

### Baselines

The repository also includes MLP and Transformer actor-critic variants used as comparison models. These are baselines rather than the main GapONet operator.

## Tasks

### HumanoidOperator

Operator environment for learning a payload-conditioned sim-real residual on paired trajectories:
- Controlled 0-3 kg payload sweep
- Upper-body action residuals for humanoid payload transfer
- Dynamics-context prediction from recent motion history
- Paired sim-real transition supervision through PPO rewards

### HumanoidAmass

AMASS-style motion tracking environment used for motion-conditioned training and baseline comparisons.

## Configuration

### Environment Configuration

Key parameters in environment configs:
- `mode`: "train" or "play"
- `num_envs`: Number of parallel environments
- `episode_length_s`: Episode length in seconds
- `max_payload_mass`: Maximum payload mass for training
- `num_sensor_positions`: Number of sensor configurations

### Network Configuration

Network-specific parameters:
- `branch_input_dims`: Input dimensions for branch networks
- `trunk_input_dim`: Input dimension for trunk network
- `hidden_dims`: Hidden layer dimensions
- `model_history_length`: Length of history buffer

## TWINS Data Format

Motion data should be provided in NumPy `.npz` format with the following keys:
- `real_dof_positions`: Joint positions
- `real_dof_velocities`: Joint velocities
- `real_dof_positions_cmd`: Target joint positions
- `real_dof_torques`: Joint torques
- `joint_sequence`: List of joint names for delta actions
- `payloads`: Payload masses

## Paper Evaluation Protocol

The paper evaluates paired sim-real tracking on 100 unseen motions, split across payloads as 35/23/22/20 motions at 0/1/2/3 kg. Each motion is executed on the physical robot and paired with its simulator replica under matched commands and gains. The platform set is Unitree H1-2, Fourier GR, and RealMan wheeled dual-arm. The main zero-shot comparison is reported over payload groups and uses LGR as the primary failure metric.

Hardware deployment is evaluated separately on an unseen H1-2 with 0-1 kg payloads. The full 0-3 kg result is established through the paired sim-real evaluation.

### Metrics

The paper reports two primary paired sim-real metrics. For each paired trajectory:

```text
g_{t,j} = q_real_{t,j} - q_sim_{t,j}
e_{t,j} = |g_{t,j}|
```

- **LGR (%)**: `100 / (T * J) * sum_t sum_j 1[e_{t,j} >= 0.5]`
- **IQR (rad)**: `Q75(e) - Q25(e)`

LGR is the primary failure metric. The 0.5 rad threshold isolates large tracking failures, while IQR summarizes the robust spread of the full absolute-error distribution.

Reported paper result: GapONet is the only evaluated method that stays below 1% LGR across the full 0-3 kg sweep; at 3 kg, GapONet reaches 0.84% LGR versus 6.25% for the strongest non-operator baseline.

## Acknowledgments

- Built on [Isaac Lab](https://isaac-sim.github.io/IsaacLab/)
- Uses [rsl_rl](https://github.com/leggedrobotics/rsl_rl) for RL algorithms
- Motion data from [AMASS](https://amass.is.tue.mpg.de/)
